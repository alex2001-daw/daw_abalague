<?php
$hora=0;
echo "<table border=1><tr><th>Hora</th></tr>";
while ($hora<24){
    echo "<tr><td>$hora</td></tr>";
}
echo "</table>";
$minut=0;
echo "<table border=1><tr><th>Minut</th></tr>";
while ($minut<69){
    echo "<tr><td>$minut</td></tr>";
}
echo "</table>";
?>